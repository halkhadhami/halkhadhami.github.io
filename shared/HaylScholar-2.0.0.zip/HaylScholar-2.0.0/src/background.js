// HaylScholar background service worker
// Free live lookups only: OpenAlex API, no paid subscription and no bundled ranking database.

const CACHE_TTL = 7 * 24 * 60 * 60 * 1000;
const CACHE_VERSION = "v3";
const API_BASE = "https://api.openalex.org";
const POLITE_EMAIL = "haylscholar@users.noreply.github.com";
const MIN_REQUEST_INTERVAL = 120;
const SOURCE_SELECT = "id,display_name,summary_stats,type,topics,topic_share,issn_l,issn,works_count,cited_by_count,is_oa,is_in_doaj,country_code,apc_usd,homepage_url,x_concepts";

let nextRequestAt = 0;
let journalSourceCountPromise = null;
const pageResultsByTab = new Map();

const countryNames = {
    US: "USA", GB: "UK", DE: "Germany", NL: "Netherlands", CH: "Switzerland",
    CN: "China", JP: "Japan", FR: "France", IT: "Italy", ES: "Spain",
    AU: "Australia", CA: "Canada", IN: "India", BR: "Brazil", KR: "South Korea",
    SE: "Sweden", DK: "Denmark", NO: "Norway", FI: "Finland", AT: "Austria",
    BE: "Belgium", PL: "Poland", CZ: "Czechia", PT: "Portugal", IE: "Ireland",
    SG: "Singapore", NZ: "New Zealand", IL: "Israel", TR: "Turkey", RU: "Russia",
    SA: "Saudi Arabia", EG: "Egypt", ZA: "South Africa", MX: "Mexico",
    CL: "Chile", CO: "Colombia", MY: "Malaysia", TH: "Thailand", PH: "Philippines",
    PK: "Pakistan", IR: "Iran", IQ: "Iraq", HK: "Hong Kong", TW: "Taiwan",
};

function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

async function waitForRequestSlot() {
    const now = Date.now();
    const wait = Math.max(0, nextRequestAt - now);
    nextRequestAt = Math.max(now, nextRequestAt) + MIN_REQUEST_INTERVAL;
    if (wait > 0) await sleep(wait);
}

async function rateLimitedFetch(url, attempts = 3) {
    let lastError = null;
    for (let attempt = 0; attempt < attempts; attempt++) {
        await waitForRequestSlot();
        try {
            const response = await fetch(url);
            const retryableStatus = response.status === 429 || response.status >= 500;
            if (!retryableStatus || attempt === attempts - 1) return response;
        } catch (error) {
            lastError = error;
            if (attempt === attempts - 1) throw error;
        }
        await sleep(350 * (attempt + 1));
    }
    throw lastError || new Error("OpenAlex request failed");
}

function isValidEmail(email) {
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email || "");
}

async function getPoliteEmail() {
    try {
        const items = await chrome.storage.local.get("sr_openalex_email");
        const email = (items.sr_openalex_email || "").trim();
        if (isValidEmail(email)) return email;
    } catch (e) {
        // Fall back below.
    }
    return POLITE_EMAIL;
}

async function withMailto(url) {
    const separator = url.includes("?") ? "&" : "?";
    return `${url}${separator}mailto=${encodeURIComponent(await getPoliteEmail())}`;
}

async function getCached(key) {
    try {
        const cached = await chrome.storage.local.get(key);
        if (cached[key]?.ts && Date.now() - cached[key].ts < CACHE_TTL) return cached[key].data;
    } catch (e) {
        // Storage can be unavailable in tests; continue with live lookup.
    }
    return null;
}

function setCached(key, data) {
    try {
        chrome.storage.local.set({ [key]: { data, ts: Date.now() } });
    } catch (e) {
        // Non-fatal.
    }
}

function cacheKey(prefix, value) {
    return `${CACHE_VERSION}_${prefix}_${value}`;
}

function cleanLookupName(name) {
    if (!name) return "";
    return name
        .replace(/\s+/g, " ")
        .replace(/^\s*(Published\s+in|Source|Publication)\s*:?\s*/i, "")
        .replace(/^\s*(In|Journal)\s*:\s*/i, "")
        .replace(/\s*(\||-|--)\s*(IEEE Xplore|Wiley Online Library|SAGE Journals|Sage Journals|ASME Digital Collection).*$/i, "")
        .replace(/^(IEEE Journals? & Magazine|IEEE Conference Publication)$/i, "")
        .replace(/\s*\(\d{4}\).*$/i, "")
        .replace(/^[\s:;,\-.]+|[\s:;,\-.]+$/g, "")
        .trim();
}

function cleanIssn(issn) {
    const compact = (issn || "").toUpperCase().replace(/[^0-9X]/g, "");
    if (compact.length !== 8) return null;
    return compact.slice(0, 4) + "-" + compact.slice(4);
}

function normalizeJournalName(name) {
    if (!name) return "";
    return cleanLookupName(name)
        .replace(/^(The|An|A)\s+/i, "")
        .replace(/\s+Journal\s+of\s+/i, " J ")
        .replace(/\s+Transactions\s+on\s+/i, " Trans ")
        .replace(/\s+Proceedings\s+of\s+/i, " Proc ")
        .replace(/\s+Letters\s*$/i, " Lett")
        .replace(/\s+Magazine\s*$/i, " Mag")
        .replace(/\s+Review\s*$/i, " Rev")
        .replace(/\s+Bulletin\s*$/i, " Bull")
        .replace(/\s+Quarterly\s*$/i, " Q")
        .replace(/\s*\([^)]*\)$/, "")
        .replace(/\s+/g, " ")
        .trim();
}

function normalizeForScore(name) {
    return cleanLookupName(name)
        .toUpperCase()
        .replace(/&/g, " AND ")
        .replace(/[^\w\s]/g, " ")
        .replace(/\bTHE\b|\bA\b|\bAN\b/g, " ")
        .replace(/\bJ\b/g, " JOURNAL ")
        .replace(/\bTRANS\b/g, " TRANSACTIONS ")
        .replace(/\bPROC\b/g, " PROCEEDINGS ")
        .replace(/\bLETT\b/g, " LETTERS ")
        .replace(/\bMAG\b/g, " MAGAZINE ")
        .replace(/\bREV\b/g, " REVIEW ")
        .replace(/\s+/g, " ")
        .trim();
}

function scoreJournalMatch(query, candidate) {
    const target = normalizeForScore(query);
    const display = normalizeForScore(candidate);
    if (!target || !display) return 0;
    if (target === display) return 100;
    if (display.startsWith(target)) return 95;
    if (display.includes(target)) return Math.max(85, 100 - (display.length - target.length));
    if (target.includes(display)) return Math.max(75, 95 - (target.length - display.length));

    const targetWords = target.split(/\s+/).filter(w => w.length > 2);
    const displayWords = new Set(display.split(/\s+/).filter(w => w.length > 2));
    if (targetWords.length === 0) return 0;

    let wordMatches = 0;
    for (const word of targetWords) {
        if (displayWords.has(word) || [...displayWords].some(displayWord => displayWord.startsWith(word) || word.startsWith(displayWord))) {
            wordMatches++;
        }
    }

    let score = (wordMatches / targetWords.length) * 80;
    if (Math.abs(target.length - display.length) < 10) score += 10;
    return Math.min(100, Math.round(score));
}

function sourceQuality(source) {
    const stats = source.summary_stats || {};
    return (source.issn_l ? 1000000 : 0) +
        (source.works_count || 0) +
        Math.round((stats["2yr_mean_citedness"] || 0) * 1000);
}

function createSearchVariations(journalName) {
    const base = cleanLookupName(journalName);
    const variations = [base];
    const normalized = normalizeJournalName(base);
    if (normalized && normalized !== base) variations.push(normalized);

    const withoutSuffix = base.replace(/\s+(?:Journal|Transactions|Proceedings|Letters|Magazine|Review|Bulletin|Quarterly)$/i, "");
    if (withoutSuffix && withoutSuffix !== base) variations.push(withoutSuffix);

    const abbreviated = base
        .replace(/\bJournal\b/gi, "J")
        .replace(/\bTransactions\b/gi, "Trans")
        .replace(/\bProceedings\b/gi, "Proc")
        .replace(/\bLetters\b/gi, "Lett")
        .replace(/\bMagazine\b/gi, "Mag")
        .replace(/\bReview\b/gi, "Rev")
        .replace(/\bBulletin\b/gi, "Bull");
    if (abbreviated && abbreviated !== base) variations.push(abbreviated);

    return [...new Set(variations.filter(value => value.length >= 3))];
}

function openAlexToken(id) {
    return (id || "").split("/").pop();
}

function fallbackQuartile(citedness) {
    if (citedness >= 3.0) return "Q1";
    if (citedness >= 1.5) return "Q2";
    if (citedness >= 0.5) return "Q3";
    if (citedness > 0) return "Q4";
    return null;
}

function quartileFromRank(rank, total) {
    if (!rank || !total) return null;
    const fraction = rank / total;
    if (fraction <= 0.25) return "Q1";
    if (fraction <= 0.50) return "Q2";
    if (fraction <= 0.75) return "Q3";
    return "Q4";
}

async function getJournalSourceCount() {
    const key = cacheKey("rank_total", "type_journal");
    const cached = await getCached(key);
    if (cached) return cached;
    if (journalSourceCountPromise) return journalSourceCountPromise;

    journalSourceCountPromise = (async () => {
        const url = await withMailto(`${API_BASE}/sources?filter=type:journal&select=id&per_page=1`);
        const response = await rateLimitedFetch(url);
        if (!response.ok) return null;
        const data = await response.json();
        const total = data.meta?.count || 0;
        if (!total) return null;
        setCached(key, total);
        return total;
    })();

    try {
        return await journalSourceCountPromise;
    } catch (error) {
        console.warn("HaylScholar: Global journal count lookup failed", error);
        return null;
    } finally {
        journalSourceCountPromise = null;
    }
}

async function getOpenAlexGlobalRank(source, metricKey, metricValue, label) {
    if (!metricValue || metricValue <= 0) return null;

    const sourceId = openAlexToken(source.id);
    const key = cacheKey("global_rank", `${sourceId}_${metricKey}_${Math.round(metricValue * 1000)}`);
    const cached = await getCached(key);
    if (cached) return cached;

    try {
        const total = await getJournalSourceCount();
        if (!total) return null;

        const encodedMetric = encodeURIComponent(`${metricKey}:>${metricValue}`).replace(/%3A/g, ":").replace(/%3E/g, "%3E");
        const higherUrl = await withMailto(`${API_BASE}/sources?filter=type:journal,${encodedMetric}&select=id&per_page=1`);
        const higherResponse = await rateLimitedFetch(higherUrl);
        if (!higherResponse.ok) return null;

        const higherData = await higherResponse.json();
        const rank = (higherData.meta?.count || 0) + 1;
        const percentile = Math.max(0, Math.min(100, Math.round((1 - ((rank - 1) / total)) * 100)));
        const result = {
            label,
            rank,
            total,
            percentile,
            quartile: quartileFromRank(rank, total),
            metric: metricKey,
            source: "OpenAlex live"
        };

        setCached(key, result);
        return result;
    } catch (error) {
        console.warn("HaylScholar: Global rank lookup failed", metricKey, error);
        return null;
    }
}

async function getOpenAlexTopicRank(source, citedness) {
    const topic = source.topics?.[0];
    const topicId = openAlexToken(topic?.id);
    if (!topicId || !citedness || citedness <= 0) return null;

    const sourceId = openAlexToken(source.id);
    const key = cacheKey("rank", `${sourceId}_${topicId}_${Math.round(citedness * 1000)}`);
    const cached = await getCached(key);
    if (cached) return cached;

    try {
        const baseFilter = `topics.id:${topicId},type:journal`;
        const totalUrl = await withMailto(`${API_BASE}/sources?filter=${baseFilter}&select=id&per_page=1`);
        const greaterUrl = await withMailto(`${API_BASE}/sources?filter=${baseFilter},summary_stats.2yr_mean_citedness:%3E${citedness}&select=id&per_page=1`);

        const [totalResponse, greaterResponse] = await Promise.all([
            rateLimitedFetch(totalUrl),
            rateLimitedFetch(greaterUrl)
        ]);
        if (!totalResponse.ok || !greaterResponse.ok) return null;

        const totalData = await totalResponse.json();
        const greaterData = await greaterResponse.json();
        const total = totalData.meta?.count || 0;
        if (total < 20) return null;

        const higherCount = greaterData.meta?.count || 0;
        const rank = higherCount + 1;
        const percentile = Math.max(0, Math.min(100, Math.round((1 - ((rank - 1) / total)) * 100)));
        const result = {
            topicId,
            topic: topic.display_name,
            subfield: topic.subfield?.display_name || null,
            field: topic.field?.display_name || null,
            rank,
            total,
            percentile,
            quartile: quartileFromRank(rank, total),
            metric: "2yr_mean_citedness",
            source: "OpenAlex live"
        };

        setCached(key, result);
        return result;
    } catch (error) {
        console.warn("HaylScholar: Topic rank lookup failed", topicId, error);
        return null;
    }
}

function extractSubject(source) {
    let subject = null, subjectDetail = null, field = null, domain = null;
    if (source.topics?.length > 0) {
        const t = source.topics[0];
        subject = t.subfield ? t.subfield.display_name : t.display_name;
        field = t.field?.display_name || null;
        domain = t.domain?.display_name || null;
        subjectDetail = field;
        if (subject === field && domain) subjectDetail = domain;
    } else if (source.x_concepts?.length > 0) {
        const sorted = [...source.x_concepts].sort((a, b) => b.score - a.score);
        subject = sorted[0].display_name;
        subjectDetail = sorted[1]?.display_name || null;
    }
    return { subject, subjectDetail, field, domain };
}

async function buildSourceResult(source, matchScore, originalQuery, lookupMethod) {
    const stats = source.summary_stats || {};
    const citedness = stats["2yr_mean_citedness"] || 0;
    const hIndex = stats.h_index || 0;
    const i10 = stats.i10_index || 0;
    const worksCount = source.works_count || 0;
    const citedByCount = source.cited_by_count || 0;
    const avgCitations = worksCount > 0 && citedByCount > 0
        ? Math.round((citedByCount / worksCount) * 100) / 100
        : null;
    const [topicRank, globalOa2yRank, globalHIndexRank, globalCitedByRank, globalWorksRank] = await Promise.all([
        getOpenAlexTopicRank(source, citedness),
        getOpenAlexGlobalRank(source, "summary_stats.2yr_mean_citedness", citedness, "Global OA2Y"),
        getOpenAlexGlobalRank(source, "summary_stats.h_index", hIndex, "Global H-index"),
        getOpenAlexGlobalRank(source, "cited_by_count", citedByCount, "Global citations"),
        getOpenAlexGlobalRank(source, "works_count", worksCount, "Global works")
    ]);
    const { subject, subjectDetail, field, domain } = extractSubject(source);
    const quartile = topicRank?.quartile || fallbackQuartile(citedness);

    return {
        name: source.display_name,
        quartile,
        quartileBasis: topicRank ? "OpenAlex topic-relative estimate" : "OpenAlex global threshold estimate",
        rankingSource: "OpenAlex live API",
        topicRank,
        globalOa2yRank,
        globalHIndexRank,
        globalCitedByRank,
        globalWorksRank,
        ranks: {
            topic: topicRank,
            globalOa2y: globalOa2yRank,
            globalHIndex: globalHIndexRank,
            globalCitedBy: globalCitedByRank,
            globalWorks: globalWorksRank
        },
        citedness: Math.round(citedness * 100) / 100,
        hIndex,
        i10Index: i10,
        citeScore: avgCitations,
        avgCitations,
        worksCount,
        citedByCount,
        subject,
        subjectDetail,
        field,
        domain,
        isOA: source.is_oa || false,
        isInDOAJ: source.is_in_doaj || false,
        country: countryNames[source.country_code] || source.country_code || null,
        countryCode: source.country_code || null,
        apcUsd: source.apc_usd || null,
        issnL: source.issn_l || null,
        issn: source.issn || [],
        homepage: source.homepage_url || null,
        openAlexId: source.id,
        matchScore,
        lookupMethod,
        originalQuery
    };
}

async function fetchSourceByIssn(issn) {
    const normalizedIssn = cleanIssn(issn);
    if (!normalizedIssn) return null;
    const key = cacheKey("issn", normalizedIssn);
    const cached = await getCached(key);
    if (cached) return cached;

    try {
        const url = await withMailto(`${API_BASE}/sources/issn:${encodeURIComponent(normalizedIssn)}?select=${SOURCE_SELECT}`);
        const response = await rateLimitedFetch(url);
        if (!response.ok) return null;
        const source = await response.json();
        if (!source?.display_name || source.type === "repository") return null;
        setCached(key, source);
        return source;
    } catch (error) {
        console.warn("HaylScholar: ISSN lookup failed", normalizedIssn, error);
        return null;
    }
}

async function lookupJournal(journalName, options = {}) {
    const journalQuery = cleanLookupName(journalName);
    const normalizedIssn = cleanIssn(options.issn || options.issnL);
    if (!journalQuery && !normalizedIssn) return null;

    const key = cacheKey("sr", normalizedIssn || journalQuery.toUpperCase().trim());
    const cached = await getCached(key);
    if (cached) return cached;

    if (normalizedIssn) {
        const source = await fetchSourceByIssn(normalizedIssn);
        if (source) {
            const result = await buildSourceResult(source, 100, journalQuery || normalizedIssn, "issn");
            setCached(key, result);
            return result;
        }
    }

    if (!journalQuery || journalQuery.length < 3) return null;
    const variations = createSearchVariations(journalQuery);

    for (const searchName of variations) {
        try {
            const encodedName = encodeURIComponent(searchName);
            const url = await withMailto(`${API_BASE}/sources?filter=display_name.search:${encodedName}&select=${SOURCE_SELECT}&per_page=5`);
            const response = await rateLimitedFetch(url);
            if (!response.ok) continue;

            const data = await response.json();
            let bestMatch = null;
            let bestScore = 0;

            for (const source of data.results || []) {
                if (source.type === "repository" || !source.display_name) continue;
                const score = Math.max(
                    scoreJournalMatch(journalQuery, source.display_name),
                    scoreJournalMatch(searchName, source.display_name),
                    scoreJournalMatch(normalizeJournalName(journalQuery), source.display_name)
                );
                if (score > bestScore || (score === bestScore && bestMatch && sourceQuality(source) > sourceQuality(bestMatch))) {
                    bestScore = score;
                    bestMatch = source;
                }
            }

            if (bestMatch && bestScore >= 30) {
                const result = await buildSourceResult(bestMatch, bestScore, journalQuery, "title");
                setCached(key, result);
                return result;
            }
        } catch (error) {
            console.warn("HaylScholar: Search variation failed", searchName, error);
        }
    }

    try {
        const url = await withMailto(`${API_BASE}/sources?search=${encodeURIComponent(journalQuery)}&select=${SOURCE_SELECT}&per_page=5`);
        const response = await rateLimitedFetch(url);
        if (response.ok) {
            const data = await response.json();
            let best = null;
            let bestScore = 0;
            for (const source of data.results || []) {
                if (source.type === "repository" || !source.display_name) continue;
                const score = scoreJournalMatch(journalQuery, source.display_name) || 20;
                if (score > bestScore || (score === bestScore && best && sourceQuality(source) > sourceQuality(best))) {
                    best = source;
                    bestScore = score;
                }
            }
            if (best) {
                const result = await buildSourceResult(best, bestScore || 20, journalQuery, "broad-search");
                setCached(key, result);
                return result;
            }
        }
    } catch (error) {
        console.error("HaylScholar: Broad source lookup failed", error);
    }

    return null;
}

function normalizeWorkTitle(title) {
    return (title || "")
        .toUpperCase()
        .replace(/[^\w\s]/g, " ")
        .replace(/\s+/g, " ")
        .trim();
}

function scoreWorkTitleMatch(query, candidate) {
    const target = normalizeWorkTitle(query);
    const display = normalizeWorkTitle(candidate);
    if (!target || !display) return 0;
    if (target === display) return 100;
    if (display.startsWith(target) || target.startsWith(display)) return 92;

    const targetWords = target.split(/\s+/).filter(w => w.length > 2);
    const displayWords = new Set(display.split(/\s+/).filter(w => w.length > 2));
    if (targetWords.length === 0) return 0;

    let matches = 0;
    for (const word of targetWords) {
        if (displayWords.has(word)) matches++;
    }
    return Math.round((matches / targetWords.length) * 90);
}

async function lookupWorkSource(workTitle) {
    const title = (workTitle || "").trim();
    if (title.length < 8) return null;

    const key = cacheKey("wt", title.toUpperCase());
    const cached = await getCached(key);
    if (cached) return cached;

    try {
        const url = await withMailto(`${API_BASE}/works?search=${encodeURIComponent(title)}&select=title,primary_location,locations&per_page=5`);
        const response = await rateLimitedFetch(url);
        if (!response.ok) return null;

        const data = await response.json();
        let bestSource = null;
        let bestScore = 0;

        for (const work of data.results || []) {
            const score = scoreWorkTitleMatch(title, work.title);
            const source = work.primary_location?.source || work.locations?.find(location => location.source)?.source;
            if (!source?.display_name || source.type === "repository") continue;
            if (score > bestScore) {
                bestScore = score;
                bestSource = source;
            }
        }

        if (!bestSource?.display_name || bestScore < 70) return null;
        const result = await lookupJournal(bestSource.display_name);
        if (result) {
            result.workTitleMatchScore = bestScore;
            result.originalWorkTitle = title;
            setCached(key, result);
        }
        return result;
    } catch (error) {
        console.warn("HaylScholar: Work-title source lookup failed", title, error);
        return null;
    }
}

function storePageResult(sender, request) {
    const tabId = sender.tab?.id;
    if (tabId === undefined) return;

    const current = pageResultsByTab.get(tabId) || {
        url: request.page?.url || sender.tab?.url || null,
        title: request.page?.title || sender.tab?.title || null,
        updatedAt: Date.now(),
        results: []
    };

    current.url = request.page?.url || current.url;
    current.title = request.page?.title || current.title;
    current.updatedAt = Date.now();

    const incoming = request.result;
    if (!incoming?.name) return;

    const key = incoming.openAlexId || incoming.name;
    const existingIndex = current.results.findIndex(item => (item.openAlexId || item.name) === key);
    if (existingIndex >= 0) current.results[existingIndex] = incoming;
    else current.results.push(incoming);

    pageResultsByTab.set(tabId, current);
}

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "lookupJournal") {
        lookupJournal(request.journalName, { issn: request.issn, issnL: request.issnL })
            .then(result => sendResponse(result))
            .catch(() => sendResponse(null));
        return true;
    }
    if (request.action === "lookupWorkSource") {
        lookupWorkSource(request.title).then(result => sendResponse(result)).catch(() => sendResponse(null));
        return true;
    }
    if (request.action === "lookupBatch") {
        Promise.all(request.journalNames.map(name => lookupJournal(name))).then(results => {
            const map = {};
            request.journalNames.forEach((name, i) => { if (results[i]) map[name] = results[i]; });
            sendResponse(map);
        }).catch(() => sendResponse({}));
        return true;
    }
    if (request.action === "recordPageResult") {
        storePageResult(sender, request);
        sendResponse({ ok: true });
        return false;
    }
    if (request.action === "getPageResults") {
        const tabId = request.tabId;
        sendResponse(pageResultsByTab.get(tabId) || { results: [] });
        return false;
    }
    if (request.action === "clearCache") {
        chrome.storage.local.get(null, items => {
            const keys = Object.keys(items).filter(k =>
                (k.startsWith("sr_") || k.startsWith("wt_") || k.startsWith("issn_") || k.startsWith("rank_") ||
                 k.startsWith(`${CACHE_VERSION}_sr_`) || k.startsWith(`${CACHE_VERSION}_wt_`) ||
                 k.startsWith(`${CACHE_VERSION}_issn_`) || k.startsWith(`${CACHE_VERSION}_rank_`)) &&
                k !== "sr_settings"
            );
            chrome.storage.local.remove(keys, () => sendResponse({ cleared: keys.length }));
        });
        return true;
    }
});

chrome.runtime.onInstalled.addListener(details => {
    if (details.reason === "install") {
        chrome.storage.local.set({
            sr_settings: {
                showQuartile: true,
                showIF: true,
                showHIndex: true,
                showSubject: true,
                showCiteScore: false,
                showOA: true,
                showCountry: true,
                showWorks: false,
                showCitations: false,
                showRank: true,
                showSource: false,
                enabled: true
            }
        });
    }
});
