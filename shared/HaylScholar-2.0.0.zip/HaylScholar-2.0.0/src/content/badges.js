// HaylScholar badge renderer

(function() {
    "use strict";

    const COLORS = {
        Q1: { bg: "#2e7d32", text: "#fff" },
        Q2: { bg: "#1565c0", text: "#fff" },
        Q3: { bg: "#ef6c00", text: "#fff" },
        Q4: { bg: "#c62828", text: "#fff" },
        if: { bg: "#6a1b9a", text: "#fff" },
        hindex: { bg: "#00838f", text: "#fff" },
        subject: { bg: "#455a64", text: "#fff" },
        citescore: { bg: "#4527a0", text: "#fff" },
        oa: { bg: "#e65100", text: "#fff" },
        oaClosed: { bg: "#616161", text: "#fff" },
        country: { bg: "#37474f", text: "#fff" },
        works: { bg: "#33691e", text: "#fff" },
        citations: { bg: "#880e4f", text: "#fff" },
        rank: { bg: "#263238", text: "#fff" },
        source: { bg: "#424242", text: "#fff" },
    };

    const pageResults = new Map();
    const DEBUG = false;

    function debugLog(...args) {
        if (DEBUG) console.log(...args);
    }

    function createBadge(text, colors, tooltip) {
        const span = document.createElement("span");
        span.className = "sr-badge";
        span.textContent = text;
        span.style.backgroundColor = colors.bg;
        span.style.color = colors.text;
        if (tooltip) span.title = tooltip;
        return span;
    }

    function formatNumber(n) {
        if (n >= 1000000) return (n / 1000000).toFixed(1) + "M";
        if (n >= 1000) return (n / 1000).toFixed(1) + "K";
        return String(n);
    }

    function defaultSettings() {
        return {
            showQuartile: true,
            showIF: true,
            showHIndex: true,
            showSubject: true,
            showCiteScore: false,
            showOA: true,
            showCountry: true,
            showWorks: false,
            showCitations: false,
            showRank: true,
            showSource: false
        };
    }

    function renderBadges(element, data, position) {
        if (element.parentNode && element.parentNode.querySelector(".sr-badge-container")) return;
        if (element.querySelector && element.querySelector(".sr-badge-container")) return;

        const container = document.createElement("span");
        container.className = "sr-badge-container";

        chrome.storage.local.get("sr_settings", function(items) {
            const s = { ...defaultSettings(), ...(items.sr_settings || {}) };

            if (s.showQuartile && data.quartile) {
                container.appendChild(createBadge(data.quartile, COLORS[data.quartile],
                    `${data.name}\nQuartile: ${data.quartile}\n${data.quartileBasis || "OpenAlex estimate"}\n2-year mean citedness: ${data.citedness}`
                ));
            }

            if (s.showIF && data.citedness > 0) {
                container.appendChild(createBadge("OA2Y " + data.citedness, COLORS.if,
                    `OpenAlex 2-year mean citedness: ${data.citedness}\nFree live metric; not official JCR Impact Factor`
                ));
            }

            if (s.showRank && data.topicRank) {
                const r = data.topicRank;
                container.appendChild(createBadge(`T#${r.rank}/${formatNumber(r.total)}`, COLORS.rank,
                    `OpenAlex topic-relative rank\nTopic: ${r.topic}\nRank: ${r.rank} of ${r.total}\nTop ${r.percentile}% by 2-year mean citedness`
                ));
            }

            if (s.showRank && data.globalOa2yRank) {
                const r = data.globalOa2yRank;
                container.appendChild(createBadge(`G2Y#${r.rank}/${formatNumber(r.total)}`, COLORS.rank,
                    `OpenAlex global OA2Y rank\nRank: ${r.rank} of ${r.total} journals\nTop ${r.percentile}% by 2-year mean citedness`
                ));
            }

            if (s.showHIndex && data.hIndex > 0) {
                container.appendChild(createBadge("H " + data.hIndex, COLORS.hindex,
                    `H-index: ${data.hIndex}\ni10-index: ${data.i10Index || "N/A"}` +
                    (data.globalHIndexRank ? `\nGlobal H-index rank: #${data.globalHIndexRank.rank} of ${data.globalHIndexRank.total}\nTop ${data.globalHIndexRank.percentile}% by H-index` : "")
                ));
            }

            if (s.showSubject && data.subject) {
                let label = data.subject;
                if (label.length > 28) label = label.substring(0, 25) + "...";
                container.appendChild(createBadge(label, COLORS.subject,
                    `Primary: ${data.subject}` +
                    (data.field ? `\nField: ${data.field}` : "") +
                    (data.domain ? `\nDomain: ${data.domain}` : "")
                ));
            }

            if (s.showCiteScore && data.citeScore) {
                container.appendChild(createBadge("AvgCite " + data.citeScore, COLORS.citescore,
                    `OpenAlex average citations per work: ${data.citeScore}\nTotal citations / total works; not official CiteScore`
                ));
            }

            if (s.showOA) {
                if (data.isOA) {
                    container.appendChild(createBadge("Open Access", COLORS.oa,
                        `Open Access journal` + (data.isInDOAJ ? `\nListed in DOAJ` : "") +
                        (data.apcUsd ? `\nAPC: $${data.apcUsd}` : "")
                    ));
                } else {
                    container.appendChild(createBadge("Subscription", COLORS.oaClosed,
                        `Subscription journal` + (data.apcUsd ? `\nOA option APC: $${data.apcUsd}` : "")
                    ));
                }
            }

            if (s.showCountry && data.country) {
                container.appendChild(createBadge("Loc " + data.country, COLORS.country,
                    `Published in: ${data.country}` + (data.countryCode ? ` (${data.countryCode})` : "")
                ));
            }

            if (s.showWorks && data.worksCount > 0) {
                container.appendChild(createBadge("Works " + formatNumber(data.worksCount), COLORS.works,
                    `Total works: ${data.worksCount.toLocaleString()}` +
                    (data.globalWorksRank ? `\nGlobal works rank: #${data.globalWorksRank.rank} of ${data.globalWorksRank.total}\nTop ${data.globalWorksRank.percentile}% by works count` : "")
                ));
            }

            if (s.showCitations && data.citedByCount > 0) {
                container.appendChild(createBadge("Cites " + formatNumber(data.citedByCount), COLORS.citations,
                    `Total citations: ${data.citedByCount.toLocaleString()}` +
                    (data.globalCitedByRank ? `\nGlobal citation rank: #${data.globalCitedByRank.rank} of ${data.globalCitedByRank.total}\nTop ${data.globalCitedByRank.percentile}% by citations` : "")
                ));
            }

            if (s.showSource) {
                container.appendChild(createBadge("OpenAlex", COLORS.source,
                    `Ranking source: ${data.rankingSource || "OpenAlex live API"}\nLookup: ${data.lookupMethod || "title"}`
                ));
            }

            if (container.children.length > 0) {
                if (position === "after") element.insertAdjacentElement("afterend", container);
                else element.appendChild(container);
            }
        });
    }

    function recordPageResult(journal, result) {
        const record = {
            ...result,
            extractedName: journal.name,
            fallbackTitle: journal.fallbackTitle || null,
            pageUrl: window.location.href,
            pageTitle: document.title,
            recordedAt: Date.now()
        };
        const key = record.openAlexId || record.name || journal.name;
        pageResults.set(key, record);
        window.__haylScholarPageResults = Array.from(pageResults.values());

        chrome.runtime.sendMessage({
            action: "recordPageResult",
            page: { url: window.location.href, title: document.title },
            result: record
        }, () => {
            void chrome.runtime.lastError;
        });
    }

    function sendLookup(payload, label) {
        return new Promise(resolve => {
            chrome.runtime.sendMessage(payload, response => {
                if (chrome.runtime.lastError) {
                    console.error("HaylScholar: Chrome runtime error:", chrome.runtime.lastError);
                    resolve(null);
                } else {
                    debugLog("HaylScholar: Lookup result for", label, ":", response ? `Found (score: ${response.matchScore || response.workTitleMatchScore || "N/A"})` : "Not found");
                    resolve(response);
                }
            });
        });
    }

    async function run() {
        const { detectWebsite, extractJournals } = window.__scholarRank || {};
        if (!detectWebsite || !extractJournals) return;

        let website;
        try {
            website = detectWebsite();
        } catch (e) {
            console.error("HaylScholar: Website detection failed", e);
            return;
        }
        if (!website) return;
        debugLog("HaylScholar: Detected:", website);

        let journals;
        try {
            journals = extractJournals(website);
        } catch (e) {
            console.error("HaylScholar: Journal extraction failed on", website, "URL:", window.location.href, e);
            return;
        }
        if (journals.length === 0) {
            debugLog("HaylScholar: No journals found on", website, "URL:", window.location.href);
            return;
        }
        debugLog("HaylScholar: Found", journals.length, "journals on", website, ":", journals.map(j => j.name));

        for (const journal of journals) {
            try {
                debugLog("HaylScholar: Looking up journal:", journal.name);
                let result = null;
                if (!journal.lookupByWorkTitle) {
                    result = await sendLookup({
                        action: "lookupJournal",
                        journalName: journal.name,
                        issn: journal.issn
                    }, journal.name);
                }
                if (!result && journal.fallbackTitle) {
                    debugLog("HaylScholar: Falling back to work-title lookup:", journal.fallbackTitle);
                    result = await sendLookup({ action: "lookupWorkSource", title: journal.fallbackTitle }, journal.fallbackTitle);
                }
                if (result) {
                    debugLog("HaylScholar: Rendering badge for", journal.name, "with quartile", result.quartile);
                    recordPageResult(journal, result);
                    renderBadges(journal.element, result, journal.position);
                } else {
                    debugLog("HaylScholar: No data found for journal:", journal.name, "on", website);
                }
            } catch (e) {
                console.error("HaylScholar: Error processing journal", journal.name, "on", website, e);
            }
        }
    }

    function debounce(fn, delay) {
        let timer;
        return function(...args) {
            clearTimeout(timer);
            timer = setTimeout(() => fn(...args), delay);
        };
    }

    function init() {
        setTimeout(run, 1000);
        setTimeout(run, 3000);
        setTimeout(run, 7000);

        const observer = new MutationObserver(debounce(() => {
            try {
                const { detectWebsite, extractJournals } = window.__scholarRank || {};
                if (detectWebsite && extractJournals) {
                    const website = detectWebsite();
                    if (website && extractJournals(website).length > 0) run();
                }
            } catch (e) {
                console.error("HaylScholar: Observer extraction failed", e);
            }
        }, 2000));

        observer.observe(document.body || document.documentElement, { childList: true, subtree: true });
    }

    chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
        if (request.action === "getHaylScholarResults") {
            sendResponse({
                url: window.location.href,
                title: document.title,
                updatedAt: Date.now(),
                results: Array.from(pageResults.values())
            });
            return false;
        }
    });

    if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", init);
    else init();
})();
