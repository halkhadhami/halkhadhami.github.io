// HaylScholar universal website detector and journal extractor
// Strategy: Use meta[name='citation_journal_title'] as universal primary method,
// with site-specific DOM selectors as fallbacks for search/listing pages.

(function() {
    'use strict';

    const hostname = window.location.hostname;
    const url = window.location.href;

    // ==================== WEBSITE DETECTION ====================

    function detectWebsite() {
        // --- Google Scholar ---
        if (hostname.includes("scholar.google")) {
            if (url.includes("/scholar?") || url.includes("start=")) return "GoogleScholar";
            if (url.includes("cites=")) return "GoogleScholar";
            return null;
        }

        // --- Web of Science ---
        if (hostname.includes("webofscience") || hostname.includes("webofknowledge") ||
            (hostname.includes("clarivate") && url.includes("wos")))
            return "WoS";

        // --- Scopus ---
        if (hostname.includes("scopus.com")) return "Scopus";

        // --- PubMed ---
        if (hostname.includes("pubmed.ncbi")) return "PubMed";

        // --- ScienceDirect / Elsevier ---
        if (hostname.includes("sciencedirect.com")) return "ScienceDirect";
        if (hostname.includes("journalfinder.elsevier.com")) return "JournalFinder";

        // --- Springer / Nature ---
        if (hostname.includes("link.springer.com")) return "Springer";
        if (hostname.includes("nature.com")) return "Nature";
        if (hostname.includes("springeropen.com")) return "SpringerOpen";

        // --- IEEE ---
        if (hostname.includes("ieeexplore.ieee.org")) return "IEEE";

        // --- Wiley ---
        if (hostname.includes("onlinelibrary.wiley.com")) return "Wiley";

        // --- Taylor & Francis ---
        if (hostname.includes("tandfonline.com")) return "TandF";

        // --- SAGE ---
        if (hostname.includes("journals.sagepub.com")) return "SAGE";

        // --- ASME ---
        if (hostname.includes("asmedigitalcollection.asme.org")) return "ASME";

        // --- MDPI ---
        if (hostname.includes("mdpi.com")) return "MDPI";

        // --- ACS ---
        if (hostname.includes("pubs.acs.org")) return "ACS";

        // --- RSC ---
        if (hostname.includes("pubs.rsc.org")) return "RSC";

        // --- Frontiers ---
        if (hostname.includes("frontiersin.org")) return "Frontiers";

        // --- Cambridge ---
        if (hostname.includes("cambridge.org")) return "Cambridge";

        // --- Oxford Academic ---
        if (hostname.includes("academic.oup.com")) return "Oxford";

        // --- JSTOR ---
        if (hostname.includes("jstor.org")) return "JSTOR";

        // --- ACM Digital Library ---
        if (hostname.includes("dl.acm.org")) return "ACM";

        // --- DBLP ---
        if (hostname.includes("dblp.org") || hostname.includes("dblp.uni-trier.de")) return "DBLP";

        // --- Semantic Scholar ---
        if (hostname.includes("semanticscholar.org")) return "SemanticScholar";

        // --- ResearchGate ---
        if (hostname.includes("researchgate.net")) return "ResearchGate";

        // --- Connected Papers ---
        if (hostname.includes("connectedpapers.com")) return "ConnectedPapers";

        // --- Emerald ---
        if (hostname.includes("emerald.com")) return "Emerald";

        // --- IOP Science ---
        if (hostname.includes("iopscience.iop.org")) return "IOP";

        // --- Annual Reviews ---
        if (hostname.includes("annualreviews.org")) return "AnnualReviews";

        // --- De Gruyter ---
        if (hostname.includes("degruyter.com")) return "DeGruyter";

        // --- Hindawi ---
        if (hostname.includes("hindawi.com")) return "Hindawi";

        // --- PLOS ---
        if (hostname.includes("plos.org") || hostname.includes("journals.plos.org")) return "PLOS";

        // --- Science (AAAS) ---
        if (hostname.includes("science.org") || hostname.includes("sciencemag.org")) return "Science";

        // --- Cell / Lancet ---
        if (hostname.includes("cell.com") || hostname.includes("thelancet.com")) return "Cell";

        // --- BMJ ---
        if (hostname.includes("bmj.com")) return "BMJ";

        // --- Elsevier (other) ---
        if (hostname.includes("elsevier.com")) return "Elsevier";

        // --- Lippincott / Wolters Kluwer ---
        if (hostname.includes("lww.com") || hostname.includes("journals.lww.com")) return "LWW";

        // --- Karger ---
        if (hostname.includes("karger.com")) return "Karger";

        // --- Thieme ---
        if (hostname.includes("thieme-connect.com")) return "Thieme";

        // --- World Scientific ---
        if (hostname.includes("worldscientific.com")) return "WorldScientific";

        // --- Informa ---
        if (hostname.includes("informaworld.com")) return "Informa";

        // --- Mary Ann Liebert ---
        if (hostname.includes("liebertpub.com")) return "Liebert";

        // --- Bentham Science ---
        if (hostname.includes("benthamscience.com")) return "Bentham";

        // --- ASCE ---
        if (hostname.includes("ascelibrary.org")) return "ASCE";

        // --- AIP ---
        if (hostname.includes("aip.scitation.org") || hostname.includes("pubs.aip.org")) return "AIP";

        // --- APS (Physical Review) ---
        if (hostname.includes("journals.aps.org")) return "APS";

        // --- EDP Sciences ---
        if (hostname.includes("edpsciences.org")) return "EDP";

        // --- SPIE ---
        if (hostname.includes("spiedigitallibrary.org")) return "SPIE";

        // --- OSA / Optica ---
        if (hostname.includes("optica.org") || hostname.includes("osapublishing.org")) return "Optica";

        // --- Copernicus ---
        if (hostname.includes("copernicus.org")) return "Copernicus";

        // --- Generic fallback: check for citation meta tags
        if (document.querySelector("meta[name='citation_journal_title']")) return "GenericArticle";

        return null;
    }

    // ==================== JOURNAL EXTRACTION ====================

    function isPublisherName(name) {
        return /^(Elsevier|Springer|Springer Nature|Wiley|Wiley Online Library|IEEE|IEEE Xplore|IEEE Journals? & Magazine|IEEE Conference Publication|SAGE|SAGE Journals|MDPI|ASME|ASME Digital Collection|Taylor & Francis|Oxford Academic)$/i.test(name);
    }

    function looksLikeDomain(text) {
        return /^(?:https?:\/\/)?(?:www\.)?[\w.-]+\.[a-z]{2,}(?:\/.*)?$/i.test((text || "").trim());
    }

    function cleanJournalName(name) {
        if (!name) return null;

        let cleaned = name
            .replace(/\s+/g, " ")
            .replace(/^\s*(Published\s+in|Source|Publication)\s*:?\s*/i, "")
            .replace(/^\s*(In|Journal)\s*:\s*/i, "")
            .replace(/\s*(\||-|--)\s*(IEEE Xplore|Wiley Online Library|SAGE Journals|Sage Journals|ASME Digital Collection).*$/i, "")
            .replace(/\s*\(\d{4}\).*$/i, "")
            .replace(/\s*View\s+all\s+.*$/i, "")
            .replace(/^\s*View\s+/i, "")
            .replace(/^[\s:;,\-.]+|[\s:;,\-.]+$/g, "")
            .trim();

        if (cleaned.length < 3 || cleaned.length > 160) return null;
        if (/^\d+$/.test(cleaned) || cleaned === "...") return null;
        if (looksLikeDomain(cleaned)) return null;
        if (isPublisherName(cleaned)) return null;
        return cleaned;
    }

    function extractGoogleScholarJournal(text) {
        if (!text) return null;

        const normalized = text
            .replace(/\u00a0/g, " ")
            .replace(/[‐‑‒–—]/g, "-")
            .replace(/\s+/g, " ")
            .trim();

        const parts = normalized.split(/\s+-\s+/).map(part => part.trim()).filter(Boolean);
        if (parts.length < 2) return null;

        const sourceParts = parts.slice(1).filter(part => !looksLikeDomain(part) && !isPublisherName(part));
        for (const part of sourceParts) {
            if (/^\s*(?:…|\.{3})/.test(part)) continue;

            let candidate = part
                .replace(/,\s*(?:19|20)\d{2}.*$/i, "")
                .replace(/\s*\b(?:19|20)\d{2}\b.*$/i, "")
                .replace(/\s*(?:…|\.{3})\s*$/g, "")
                .replace(/^\s*(?:…|\.{3})\s*/g, "")
                .trim();

            if (cleanJournalName(candidate)) return candidate;
        }

        return null;
    }

    function cleanGoogleScholarTitle(title) {
        return (title || "")
            .replace(/^\s*\[[^\]]+\]\s*/i, "")
            .replace(/\s+/g, " ")
            .trim();
    }

    function shouldUseWorkTitleForScholar(journalName, fallbackTitle) {
        if (!journalName || !fallbackTitle || fallbackTitle.length < 18) return false;
        if (/[?]/.test(journalName)) return true;
        if (/\b(and|in|of|for|on|with|from)$/i.test(journalName)) return true;
        return false;
    }

    function addJournal(journals, name, element, position = "after") {
        const cleaned = cleanJournalName(name);
        if (!cleaned || !element) return null;
        const existing = journals.find(j => j.element === element && j.name.toLowerCase() === cleaned.toLowerCase());
        if (existing) return existing;
        const journal = { name: cleaned, element, position };
        journals.push(journal);
        return journal;
    }

    function getMetaContent(selectors) {
        for (const selector of selectors) {
            const meta = document.querySelector(selector);
            const content = cleanJournalName(meta?.getAttribute("content"));
            if (content) return content;
        }
        return null;
    }

    function getIssnFromMeta() {
        const selectors = [
            "meta[name='citation_issn']",
            "meta[name='prism.issn']",
            "meta[name='issn']",
            "meta[name='dc.Identifier']",
            "meta[name='DC.Identifier']"
        ];
        for (const selector of selectors) {
            const value = document.querySelector(selector)?.getAttribute("content") || "";
            const match = value.match(/\b\d{4}[- ]?\d{3}[\dX]\b/i);
            if (match) return match[0].toUpperCase().replace(/\s/g, "");
        }
        return null;
    }

    function parseJsonString(value) {
        try {
            return JSON.parse(`"${value}"`);
        } catch (e) {
            return value.replace(/\\"/g, '"').replace(/\\u0026/g, "&");
        }
    }

    function getJournalFromIEEEMetadata() {
        for (const script of document.querySelectorAll("script")) {
            const text = script.textContent || "";
            if (!text.includes("publicationTitle") && !text.includes("displayPublicationTitle")) continue;

            const displayMatch = text.match(/"displayPublicationTitle"\s*:\s*"((?:\\.|[^"\\])*)"/);
            const titleMatch = text.match(/"publicationTitle"\s*:\s*"((?:\\.|[^"\\])*)"/);
            const title = cleanJournalName(parseJsonString(displayMatch?.[1] || titleMatch?.[1] || ""));
            if (title) return title;
        }
        return null;
    }

    function getJournalFromJsonLd() {
        function findName(value) {
            if (!value) return null;
            if (Array.isArray(value)) {
                for (const item of value) {
                    const found = findName(item);
                    if (found) return found;
                }
                return null;
            }
            if (typeof value !== "object") return null;

            const type = Array.isArray(value["@type"]) ? value["@type"].join(" ") : (value["@type"] || "");
            if (/Periodical|PublicationVolume|PublicationIssue|Journal/i.test(type)) {
                const name = cleanJournalName(value.name || value.headline);
                if (name) return name;
            }

            const nested = findName(value.isPartOf) || findName(value.journal) || findName(value.periodical);
            if (nested) return nested;
            return null;
        }

        for (const script of document.querySelectorAll("script[type='application/ld+json']")) {
            try {
                const parsed = JSON.parse(script.textContent);
                const found = findName(parsed);
                if (found) return found;
            } catch (e) {
                // Some publisher JSON-LD blocks are malformed; keep trying other blocks.
            }
        }
        return null;
    }

    // Universal: extract journal name from standard meta tags and structured data.
    function getJournalFromMeta() {
        const metaName = getMetaContent([
            "meta[name='citation_journal_title']",
            "meta[name='citation_publication_title']",
            "meta[name='prism.publicationName']",
            "meta[name='prism.publicationname']",
            "meta[name='dc.Source']",
            "meta[name='DC.Source']",
            "meta[name='dc.source']",
            "meta[name='journal_title']",
            "meta[name='citation_journal_abbrev']"
        ]);
        if (metaName) return metaName;

        const structuredName = getJournalFromJsonLd();
        if (structuredName) return structuredName;

        const ieeeName = getJournalFromIEEEMetadata();
        if (ieeeName) return ieeeName;

        const ogSiteName = document.querySelector("meta[property='og:site_name']");
        const ogName = cleanJournalName(ogSiteName?.getAttribute("content"));
        if (ogName && !isPublisherName(ogName)) return ogName;

        return null;
    }

    // Find the best element to attach badges to
    function findInsertionPoint() {
        // Try article title first
        const selectors = [
            "h1.article-title", "h1.document-title", "h1.citation__title",
            "h1.c-article-title", "h1.wi-article-title", "h1.article__title",
            "h1.highwire-cite-title", "h1.item-title", "h1.publicationContentTitle",
            "h1.heading-title", "h1.content-title",
            ".article-header h1", ".document-header h1", ".article-title",
            "#article-title", ".title-text", ".article-dochead",
            "h1[data-article-title]", "h1.ChapterTitle",
            "h1.page-title", "h1.entry-title",
            "h1", // Last resort
        ];

        for (const sel of selectors) {
            const el = document.querySelector(sel);
            if (el && el.textContent.trim().length > 3) return el;
        }
        return null;
    }

    // Extract journal names — returns array of {name, element, position}
    function extractJournals(website) {
        const journals = [];

        // ============ SEARCH/LISTING PAGES ============

        if (website === "GoogleScholar") {
            document.querySelectorAll(".gs_ri").forEach(item => {
                if (item.querySelector(".sr-badge-container")) return;
                const venueEl = item.querySelector(".gs_a");
                if (!venueEl) return;
                const parsedJournal = extractGoogleScholarJournal(venueEl.textContent);
                const titleEl = item.querySelector(".gs_rt a, .gs_rt");
                const fallbackTitle = cleanGoogleScholarTitle(titleEl?.textContent);
                if (shouldUseWorkTitleForScholar(parsedJournal, fallbackTitle)) {
                    journals.push({ name: fallbackTitle, fallbackTitle, lookupByWorkTitle: true, element: venueEl, position: "after" });
                    return;
                }
                const journal = addJournal(journals, parsedJournal, venueEl);
                if (journal && fallbackTitle) journal.fallbackTitle = fallbackTitle;
                if (!journal && fallbackTitle) {
                    journals.push({ name: fallbackTitle, fallbackTitle, lookupByWorkTitle: true, element: venueEl, position: "after" });
                }
                return;
                const text = venueEl.textContent;
                const parts = text.split(" - ");
                if (parts.length >= 2) {
                    let journal = parts[1].replace(/,\s*\d{4}.*$/, "").trim();
                    if (journal.length >= 3 && !/^\d+$/.test(journal) && journal !== "…") {
                        addJournal(journals, journal, venueEl);
                    }
                }
            });
            return journals;
        }

        // IEEE Xplore search results
        if (website === "IEEE" && (url.includes("/searchresult.jsp") || url.includes("/search/"))) {
            document.querySelectorAll(".List-results-items, .xpl-results-item, xpl-results-item, .result-item, [class*='List-results-item']").forEach(item => {
                if (item.querySelector(".sr-badge-container")) return;
                const pubInfo = item.querySelector(".description span:nth-child(2), .source-title, .publication-title, [class*='source-title'], [class*='publication-title']");
                const titleEl = item.querySelector(".result-item-title a, h2 a, h3 a, a[href*='/document/']") || pubInfo;
                if (pubInfo && titleEl) {
                    let journal = pubInfo.textContent.trim().replace(/\s*\(\d{4}\).*$/, "");
                    addJournal(journals, journal, titleEl);
                }
            });
            return journals;
        }

        // Wiley search results
        if (website === "Wiley" && (url.includes("/action/doSearch") || url.includes("/search"))) {
            document.querySelectorAll(".result__title, .issue-item__title, .citation__title, .hlFld-Title, h3 a[href*='/doi/'], a[href*='/doi/']").forEach(titleEl => {
                if (titleEl.querySelector(".sr-badge-container")) return;
                const pubInfo = titleEl.closest('.result-item, .issue-item, .search__item, .search-result, li, article')?.querySelector('.meta__1, .meta__2, .series-title, .citation__journal-title, .journal-title, .publication-title, a[href*="/journal/"]');
                if (pubInfo) {
                    let journal = pubInfo.textContent.trim();
                    addJournal(journals, journal, titleEl);
                }
            });
            return journals;
        }

        // SAGE search results
        if (website === "SAGE" && url.includes("/search")) {
            document.querySelectorAll(".search-item-title, .issue-item__title, .citation__title, .hlFld-Title, h3 a[href*='/doi/'], a[href*='/doi/']").forEach(titleEl => {
                if (titleEl.querySelector(".sr-badge-container")) return;
                const pubInfo = titleEl.closest('.search-item, .result-item, .search-result, li, article')?.querySelector('.publication-title, .citation__journal-title, .journal-title, a[href*="/home/"]');
                if (pubInfo) {
                    let journal = pubInfo.textContent.trim();
                    addJournal(journals, journal, titleEl);
                }
            });
            return journals;
        }

        // ASME search results
        if (website === "ASME" && url.includes("/search")) {
            document.querySelectorAll(".search-result-title, .al-article-title, .hlFld-Title, h3 a[href*='/article/'], a[href*='/article/']").forEach(titleEl => {
                if (titleEl.querySelector(".sr-badge-container")) return;
                const pubInfo = titleEl.closest('.search-result, .al-search-result, .item, li, article')?.querySelector('.journal-title, .publication-title, .ww-citation-primary__journal-title, a[href*="/journal/"]');
                if (pubInfo) {
                    let journal = pubInfo.textContent.trim();
                    addJournal(journals, journal, titleEl);
                }
            });
            return journals;
        }

        if (website === "JournalFinder") {
            document.querySelectorAll("[class*='journal-card'], .ResultItem, .result-item").forEach(card => {
                if (card.querySelector(".sr-badge-container")) return;
                const h2 = card.querySelector("h2, h3, .journal-title");
                if (h2) addJournal(journals, h2.textContent, h2);
            });
            return journals;
        }

        if (website === "PubMed" && (url.includes("term=") || url.includes("/?q="))) {
            document.querySelectorAll("article.full-docsum, .docsum-content, .search-results-chunk .results-article").forEach(item => {
                if (item.querySelector(".sr-badge-container")) return;
                const journalEl = item.querySelector(".docsum-journal-citation, .full-journal-citation, .short-journal-citation");
                if (journalEl) {
                    let name = journalEl.textContent.split(".")[0].trim();
                    if (name.length >= 3) {
                        const titleEl = item.querySelector("a.docsum-title, .docsum-title") || journalEl;
                        addJournal(journals, name, titleEl);
                    }
                }
            });
            return journals;
        }

        if (website === "Scopus" && (url.includes("/results/") || url.includes("/search/"))) {
            document.querySelectorAll("[data-testid='results-list'] > li, .searchArea tr, .result-item").forEach(item => {
                if (item.querySelector(".sr-badge-container")) return;
                const srcEl = item.querySelector(".source-title, td.sourceTitle a, .source-title-link");
                const titleEl = item.querySelector("h2 a, .title a, a[data-testid='title-link']") || srcEl;
                if (srcEl && titleEl) {
                    addJournal(journals, srcEl.textContent, titleEl);
                }
            });
            return journals;
        }

        if (website === "WoS" && (url.includes("/summary/") || url.includes("/results/"))) {
            document.querySelectorAll("[data-testid='search-records-list'] > div, .search-results-item, app-record").forEach(item => {
                if (item.querySelector(".sr-badge-container")) return;
                const srcEl = item.querySelector(".source-title, .search-results-source-title-link, [data-testid='summary-source-title-link']");
                const titleEl = item.querySelector("a[data-testid='summary-record-title-link'], .title a, h3 a") || srcEl;
                if (srcEl && titleEl) {
                    addJournal(journals, srcEl.textContent, titleEl);
                }
            });
            return journals;
        }

        // ============ JOURNAL HOME PAGES ============

        // ScienceDirect journal page
        if (website === "ScienceDirect" && url.includes("/journal/")) {
            const titleEl = document.querySelector("h1, .journal-title, .publication-title");
            if (titleEl && !titleEl.querySelector(".sr-badge-container")) {
                let name = document.title.replace(/ - ScienceDirect.*$/i, "").replace(/\s*\|.*$/, "").trim();
                if (!name || name.length < 3) name = titleEl.textContent.trim();
                addJournal(journals, name, titleEl);
            }
            return journals;
        }

        // Springer journal page
        if (website === "Springer" && url.includes("/journal/")) {
            const titleEl = document.querySelector("h1, .app-journal-masthead__title, .c-journal-title");
            if (titleEl && !titleEl.querySelector(".sr-badge-container")) {
                addJournal(journals, titleEl.textContent, titleEl);
            }
            return journals;
        }

        // ============ ARTICLE DETAIL PAGES (Universal Meta Tag Approach) ============
        // This works for: ScienceDirect, Springer, IEEE, Wiley, SAGE, ASME, T&F,
        // MDPI, ACS, RSC, Frontiers, Cambridge, Oxford, ACM, Nature, Cell, Lancet,
        // BMJ, LWW, Karger, Thieme, ASCE, AIP, APS, IOP, SPIE, Optica, PLOS,
        // Science (AAAS), Emerald, De Gruyter, Hindawi, WorldScientific, and more.

        const journalName = getJournalFromMeta();
        if (journalName && journalName.length >= 3) {
            const insertEl = findInsertionPoint();
            if (insertEl && !insertEl.querySelector(".sr-badge-container") &&
                !insertEl.parentNode?.querySelector(".sr-badge-container")) {
                const journal = addJournal(journals, journalName, insertEl);
                if (journal) journal.issn = getIssnFromMeta();
            }
            return journals;
        }

        // ============ SPECIFIC PUBLISHER FALLBACKS FOR ARTICLE PAGES ============

        // IEEE article page fallback
        if (website === "IEEE") {
            const ieeeJournal = document.querySelector(".stats__source-title, .u-pb-1 .u-h5, .publication-title, [class*='source-title']");
            if (ieeeJournal) {
                const insertEl = findInsertionPoint();
                if (insertEl && !insertEl.querySelector(".sr-badge-container")) {
                    const journal = addJournal(journals, ieeeJournal.textContent, insertEl);
                    if (journal) journal.issn = getIssnFromMeta();
                }
                return journals;
            }
        }

        // Wiley article page fallback
        if (website === "Wiley") {
            const wileyJournal = document.querySelector(".journal-banner__title, .citation-journal-title, .citation__journal-title, .journal-header__title, a[href*='/journal/']");
            if (wileyJournal) {
                const insertEl = findInsertionPoint();
                if (insertEl && !insertEl.querySelector(".sr-badge-container")) {
                    const journal = addJournal(journals, wileyJournal.textContent, insertEl);
                    if (journal) journal.issn = getIssnFromMeta();
                }
                return journals;
            }
        }

        // SAGE article page fallback
        if (website === "SAGE") {
            const sageJournal = document.querySelector(".journal-banner h1, .journal-header h1, .publication-title a, .journal-content-header a[href*='/home/'], a[href*='/home/'], .toc-heading");
            if (sageJournal) {
                const insertEl = findInsertionPoint();
                if (insertEl && !insertEl.querySelector(".sr-badge-container")) {
                    const journal = addJournal(journals, sageJournal.textContent, insertEl);
                    if (journal) journal.issn = getIssnFromMeta();
                }
                return journals;
            }
        }

        // ASME article page fallback
        if (website === "ASME") {
            const asmeJournal = document.querySelector(".journal-title, .publication-title, .ww-citation-primary__journal-title, a[href*='/journal/']") ||
                [...document.querySelectorAll("h1, h2, a")].find(el => /journal/i.test(el.textContent));
            if (asmeJournal) {
                const insertEl = findInsertionPoint();
                if (insertEl && !insertEl.querySelector(".sr-badge-container")) {
                    const journal = addJournal(journals, asmeJournal.textContent, insertEl);
                    if (journal) journal.issn = getIssnFromMeta();
                }
                return journals;
            }
        }

        // ============ FALLBACK: Try page title for journal pages ============
        // For journal home pages without meta tags
        const h1 = document.querySelector("h1");
        if (h1 && h1.textContent.trim().length >= 5 && h1.textContent.trim().length < 100) {
            // Check if this looks like a journal page (not an article)
            const isJournalPage = url.includes("/journal") || url.includes("/toc/") ||
                url.includes("/loi/") || url.includes("/home/") ||
                document.querySelector(".journal-banner, .journal-header, .journal-info");
            if (isJournalPage && !h1.querySelector(".sr-badge-container")) {
                addJournal(journals, h1.textContent, h1);
            }
        }

        return journals;
    }

    // Export for badges.js
    window.__scholarRank = { detectWebsite, extractJournals };
})();
