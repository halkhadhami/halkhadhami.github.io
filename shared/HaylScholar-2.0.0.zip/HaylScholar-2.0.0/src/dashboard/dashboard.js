const params = new URLSearchParams(location.search);
const tabId = Number(params.get("tabId"));
let currentResults = [];

const els = {
    pageContext: document.getElementById("pageContext"),
    emptyState: document.getElementById("emptyState"),
    content: document.getElementById("content"),
    journalCount: document.getElementById("journalCount"),
    q1Share: document.getElementById("q1Share"),
    medianCitedness: document.getElementById("medianCitedness"),
    oaShare: document.getElementById("oaShare"),
    top10Share: document.getElementById("top10Share"),
    quartileChart: document.getElementById("quartileChart"),
    scatterPlot: document.getElementById("scatterPlot"),
    journalTable: document.getElementById("journalTable"),
    sourceNote: document.getElementById("sourceNote"),
    refreshBtn: document.getElementById("refreshBtn"),
    exportBtn: document.getElementById("exportBtn")
};

function fmtNumber(value, digits = 2) {
    if (value === null || value === undefined || Number.isNaN(Number(value))) return "-";
    const n = Number(value);
    if (Math.abs(n) >= 1000) return n.toLocaleString(undefined, { maximumFractionDigits: 1 });
    return n.toLocaleString(undefined, { maximumFractionDigits: digits });
}

function median(values) {
    const sorted = values.filter(value => Number.isFinite(value)).sort((a, b) => a - b);
    if (sorted.length === 0) return null;
    const mid = Math.floor(sorted.length / 2);
    return sorted.length % 2 ? sorted[mid] : (sorted[mid - 1] + sorted[mid]) / 2;
}

function escapeHtml(value) {
    return String(value ?? "")
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;");
}

function qClass(q) {
    return q ? q.toLowerCase() : "qx";
}

function fmtRank(rank) {
    return rank ? `#${fmtNumber(rank.rank, 0)}/${fmtNumber(rank.total, 0)}` : "-";
}

function normalizeResults(results) {
    const byId = new Map();
    for (const result of results || []) {
        const key = result.openAlexId || result.name;
        if (!key) continue;
        byId.set(key, result);
    }
    return [...byId.values()].sort((a, b) => {
        const ar = a.topicRank?.rank || a.globalOa2yRank?.rank || 999999;
        const br = b.topicRank?.rank || b.globalOa2yRank?.rank || 999999;
        if (ar !== br) return ar - br;
        return (b.citedness || 0) - (a.citedness || 0);
    });
}

function renderSummary(results) {
    const total = results.length;
    const q1 = results.filter(r => r.quartile === "Q1").length;
    const oa = results.filter(r => r.isOA).length;
    const top10 = results.filter(r => (r.globalOa2yRank?.percentile || 0) >= 90).length;
    const med = median(results.map(r => Number(r.citedness)));

    els.journalCount.textContent = String(total);
    els.q1Share.textContent = total ? Math.round((q1 / total) * 100) + "%" : "0%";
    els.medianCitedness.textContent = med === null ? "-" : fmtNumber(med);
    els.oaShare.textContent = total ? Math.round((oa / total) * 100) + "%" : "0%";
    els.top10Share.textContent = total ? Math.round((top10 / total) * 100) + "%" : "0%";
}

function renderQuartiles(results) {
    const counts = { Q1: 0, Q2: 0, Q3: 0, Q4: 0, NA: 0 };
    for (const result of results) {
        if (counts[result.quartile] !== undefined) counts[result.quartile]++;
        else counts.NA++;
    }
    const max = Math.max(1, ...Object.values(counts));
    els.quartileChart.innerHTML = ["Q1", "Q2", "Q3", "Q4", "NA"].map(q => {
        const width = Math.round((counts[q] / max) * 100);
        return `
            <div class="bar-row">
                <strong>${q}</strong>
                <div class="bar-track"><div class="bar-fill ${qClass(q)}" style="width:${width}%"></div></div>
                <span>${counts[q]}</span>
            </div>
        `;
    }).join("");
}

function renderScatter(results) {
    const svg = els.scatterPlot;
    const width = svg.clientWidth || 600;
    const height = svg.clientHeight || 300;
    const pad = { left: 46, right: 20, top: 18, bottom: 36 };
    const points = results.filter(r => Number.isFinite(Number(r.citedness)) && Number.isFinite(Number(r.hIndex)));
    const maxX = Math.max(1, ...points.map(r => Number(r.citedness)));
    const maxY = Math.max(1, ...points.map(r => Number(r.hIndex)));
    const x = value => pad.left + (Number(value) / maxX) * (width - pad.left - pad.right);
    const y = value => height - pad.bottom - (Number(value) / maxY) * (height - pad.top - pad.bottom);

    const circles = points.map(r => {
        const title = escapeHtml(`${r.name}\nOA2Y: ${fmtNumber(r.citedness)}\nH-index: ${r.hIndex}`);
        return `<circle cx="${x(r.citedness)}" cy="${y(r.hIndex)}" r="6" class="${qClass(r.quartile)}"><title>${title}</title></circle>`;
    }).join("");

    svg.setAttribute("viewBox", `0 0 ${width} ${height}`);
    svg.innerHTML = `
        <line x1="${pad.left}" y1="${height - pad.bottom}" x2="${width - pad.right}" y2="${height - pad.bottom}" stroke="#b9c1cc" />
        <line x1="${pad.left}" y1="${pad.top}" x2="${pad.left}" y2="${height - pad.bottom}" stroke="#b9c1cc" />
        <text x="${width / 2}" y="${height - 8}" text-anchor="middle" font-size="12" fill="#5c6675">OpenAlex 2-year mean citedness</text>
        <text x="13" y="${height / 2}" text-anchor="middle" font-size="12" fill="#5c6675" transform="rotate(-90 13 ${height / 2})">H-index</text>
        ${circles}
    `;
}

function renderTable(results) {
    els.journalTable.innerHTML = results.map(r => {
        const rank = fmtRank(r.topicRank);
        const globalOa2y = fmtRank(r.globalOa2yRank);
        const globalH = fmtRank(r.globalHIndexRank);
        const globalCites = fmtRank(r.globalCitedByRank);
        const globalWorks = fmtRank(r.globalWorksRank);
        const subject = r.topicRank?.topic || r.subject || "-";
        const source = r.rankingSource || "OpenAlex live API";
        return `
            <tr>
                <td class="journal-name">
                    ${escapeHtml(r.name)}
                    <div class="muted">${escapeHtml(source)}</div>
                </td>
                <td><span class="q-badge ${qClass(r.quartile)}">${escapeHtml(r.quartile || "-")}</span></td>
                <td>${escapeHtml(rank)}</td>
                <td>${escapeHtml(globalOa2y)}</td>
                <td>${escapeHtml(globalH)}</td>
                <td>${escapeHtml(globalCites)}</td>
                <td>${escapeHtml(globalWorks)}</td>
                <td>${fmtNumber(r.citedness)}</td>
                <td>${fmtNumber(r.hIndex, 0)}</td>
                <td>${escapeHtml(subject)}</td>
                <td>${r.isOA ? "Yes" : "No"}</td>
                <td>${escapeHtml(r.country || "-")}</td>
            </tr>
        `;
    }).join("");
}

function render(data) {
    currentResults = normalizeResults(data.results || []);
    els.pageContext.textContent = data.title || data.url || "Current page";

    if (currentResults.length === 0) {
        els.emptyState.classList.remove("hidden");
        els.content.classList.add("hidden");
        return;
    }

    els.emptyState.classList.add("hidden");
    els.content.classList.remove("hidden");
    els.sourceNote.textContent = "Live OpenAlex data; no paid or bundled ranking database";
    renderSummary(currentResults);
    renderQuartiles(currentResults);
    renderScatter(currentResults);
    renderTable(currentResults);
}

function getBackgroundResults() {
    return new Promise(resolve => {
        if (!Number.isFinite(tabId)) {
            resolve({ results: [] });
            return;
        }
        chrome.runtime.sendMessage({ action: "getPageResults", tabId }, response => {
            resolve(response || { results: [] });
        });
    });
}

function getContentResults() {
    return new Promise(resolve => {
        if (!Number.isFinite(tabId)) {
            resolve({ results: [] });
            return;
        }
        chrome.tabs.sendMessage(tabId, { action: "getHaylScholarResults" }, response => {
            if (chrome.runtime.lastError) resolve({ results: [] });
            else resolve(response || { results: [] });
        });
    });
}

async function load() {
    const fromBackground = await getBackgroundResults();
    if (fromBackground.results?.length) render(fromBackground);
    else render(await getContentResults());
}

function exportCsv() {
    if (currentResults.length === 0) return;
    const headers = [
        "Journal", "Quartile", "Topic Rank", "Topic Total", "Global OA2Y Rank",
        "Global OA2Y Total", "Global H-index Rank", "Global H-index Total",
        "Global Citation Rank", "Global Citation Total", "Global Works Rank",
        "Global Works Total", "OA2Y", "H-index", "Subject", "Open Access",
        "Country", "OpenAlex ID"
    ];
    const rows = currentResults.map(r => [
        r.name,
        r.quartile || "",
        r.topicRank?.rank || "",
        r.topicRank?.total || "",
        r.globalOa2yRank?.rank || "",
        r.globalOa2yRank?.total || "",
        r.globalHIndexRank?.rank || "",
        r.globalHIndexRank?.total || "",
        r.globalCitedByRank?.rank || "",
        r.globalCitedByRank?.total || "",
        r.globalWorksRank?.rank || "",
        r.globalWorksRank?.total || "",
        r.citedness || "",
        r.hIndex || "",
        r.topicRank?.topic || r.subject || "",
        r.isOA ? "Yes" : "No",
        r.country || "",
        r.openAlexId || ""
    ]);
    const csv = [headers, ...rows]
        .map(row => row.map(value => `"${String(value).replace(/"/g, '""')}"`).join(","))
        .join("\n");
    const blob = new Blob([csv], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = "haylscholar-journals.csv";
    link.click();
    URL.revokeObjectURL(url);
}

els.refreshBtn.addEventListener("click", load);
els.exportBtn.addEventListener("click", exportCsv);
window.addEventListener("resize", () => renderScatter(currentResults));

load();
