// HaylScholar popup settings

document.addEventListener("DOMContentLoaded", function() {
    const defaultOpenAlexEmail = "haylscholar@users.noreply.github.com";
    const ids = [
        "showQuartile", "showRank", "showIF", "showHIndex", "showSubject",
        "showCiteScore", "showOA", "showCountry", "showWorks", "showCitations",
        "showSource"
    ];
    const checkboxes = {};
    ids.forEach(id => checkboxes[id] = document.getElementById(id));
    const emailInput = document.getElementById("openAlexEmail");
    const emailStatus = document.getElementById("emailStatus");

    const defaults = {
        showQuartile: true,
        showRank: true,
        showIF: true,
        showHIndex: true,
        showSubject: true,
        showCiteScore: false,
        showOA: true,
        showCountry: true,
        showWorks: false,
        showCitations: false,
        showSource: false
    };

    chrome.storage.local.get("sr_settings", function(items) {
        const settings = { ...defaults, ...(items.sr_settings || {}) };
        ids.forEach(id => {
            if (checkboxes[id]) checkboxes[id].checked = settings[id];
        });
    });

    chrome.storage.local.get("sr_openalex_email", function(items) {
        emailInput.value = items.sr_openalex_email || "";
        emailInput.placeholder = defaultOpenAlexEmail;
        emailStatus.textContent = emailInput.value ? "Using your contact email" : "Using default contact email";
    });

    function isValidEmail(email) {
        return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email || "");
    }

    function saveOpenAlexEmail() {
        const email = emailInput.value.trim();
        if (!email) {
            chrome.storage.local.remove("sr_openalex_email", function() {
                emailStatus.textContent = "Using default contact email";
            });
            return;
        }
        if (!isValidEmail(email)) {
            emailStatus.textContent = "Invalid email. Leave blank to use default.";
            return;
        }
        chrome.storage.local.set({ sr_openalex_email: email }, function() {
            emailStatus.textContent = "Saved contact email";
        });
    }

    emailInput.addEventListener("change", saveOpenAlexEmail);
    emailInput.addEventListener("blur", saveOpenAlexEmail);

    ids.forEach(id => {
        if (!checkboxes[id]) return;
        checkboxes[id].addEventListener("change", function() {
            const settings = { enabled: true };
            ids.forEach(settingId => {
                settings[settingId] = checkboxes[settingId] ? checkboxes[settingId].checked : defaults[settingId];
            });
            chrome.storage.local.set({ sr_settings: settings });
        });
    });

    document.getElementById("openDashboard").addEventListener("click", function() {
        chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
            const tabId = tabs[0]?.id;
            const url = chrome.runtime.getURL("dashboard/dashboard.html" + (tabId !== undefined ? `?tabId=${tabId}` : ""));
            window.open(url, "_blank");
        });
    });

    document.getElementById("clearCache").addEventListener("click", function() {
        chrome.runtime.sendMessage({ action: "clearCache" }, function(response) {
            const status = document.getElementById("cacheStatus");
            status.textContent = "Cleared " + (response?.cleared || 0) + " cached entries";
            setTimeout(() => status.textContent = "", 3000);
        });
    });
});
